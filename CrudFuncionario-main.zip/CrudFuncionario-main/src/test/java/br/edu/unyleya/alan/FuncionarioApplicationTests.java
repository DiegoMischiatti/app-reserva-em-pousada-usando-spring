package br.edu.unyleya.alan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FuncionarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
